const express = require('express');
const multer  = require('multer');
const Paper   = require('../models/Paper');
const { uploadBuffer } = require('../utils/azure');
const { protectAdmin } = require('../middleware/auth');

const router = express.Router();
const upload = multer();  // in‑memory storage

// POST /api/papers         → create new paper + upload PDF
router.post('/', upload.single('pdf'), async (req, res) => {
  try {
    const { title, authors, keywords, abstract, content } = req.body;
    const fileUrl = req.file
      ? await uploadBuffer(req.file.buffer, req.file.originalname, req.file.mimetype)
      : undefined;

    const paper = new Paper({
      title,
      authors: authors.split(',').map(a=>a.trim()),
      keywords: (keywords||'').split(',').map(k=>k.trim()),
      abstract,
      content,
      fileUrl
    });
    await paper.save();
    res.status(201).json(paper);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// GET /api/papers          → list all papers
router.get('/', async (req, res) => {
  const list = await Paper.find().sort('-createdAt');
  res.json(list);
});

// GET /api/papers/:id      → get one paper
router.get('/:id', async (req, res) => {
  const p = await Paper.findById(req.params.id);
  if (!p) return res.status(404).json({ message: 'Not found' });
  res.json(p);
});

// PATCH /api/papers/:id/status → admin only: update status
router.patch('/:id/status', protectAdmin, async (req, res) => {
  const { status } = req.body;
  if (!['draft','submitted','published'].includes(status)) {
    return res.status(400).json({ message: 'Invalid status' });
  }
  const p = await Paper.findByIdAndUpdate(
    req.params.id,
    { status },
    { new: true }
  );
  if (!p) return res.status(404).json({ message: 'Not found' });
  res.json(p);
});

module.exports = router;
