const express = require('express');
const jwt     = require('jsonwebtoken');
const Admin   = require('../models/Admin');
require('dotenv').config();

const router = express.Router();

// POST /api/admin/login → username & password in body
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const admin = await Admin.findOne({ username });
  if (!admin || !(await admin.checkPassword(password))) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }
  const token = jwt.sign(
    { id: admin._id, username: admin.username },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN }
  );
  res.json({ token });
});

module.exports = router;
