// quick Node snippet:
const mongoose = require('mongoose');
const Admin    = require('./models/Admin');
require('dotenv').config();

mongoose.connect(process.env.MONGO_URI).then(async () => {
  const a = new Admin({
    username: process.env.ADMIN_USERNAME,
    password: process.env.ADMIN_PASSWORD
  });
  await a.save();
  console.log('Admin created');
  process.exit();
});
