const mongoose = require('mongoose');

const paperSchema = new mongoose.Schema({
  title:           { type: String, required: true, trim: true },
  authors:         { type: [String], required: true },
  keywords:        { type: [String], default: [] },
  status:          { type: String, enum: ['draft','submitted','published'], default: 'draft' },
  publicationDate: { type: Date },
  abstract:        { type: String, required: true },
  content:         { type: String, required: true },
  fileUrl:         { type: String }       // URL of uploaded PDF
}, { timestamps: true });

module.exports = mongoose.model('Paper', paperSchema);
